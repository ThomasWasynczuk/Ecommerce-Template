// <!-- The core Firebase JS SDK is always required and must be listed first -->
// <script src="https://www.gstatic.com/firebasejs/7.5.0/firebase-app.js"></script>

// <!-- TODO: Add SDKs for Firebase products that you want to use
//      https://firebase.google.com/docs/web/setup#available-libraries -->
// <script src="https://www.gstatic.com/firebasejs/7.5.0/firebase-analytics.js"></script>

import firebase from "firebase";
import "firebase/auth";


  // Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCG9CEMR4ClQpP_X2dDkm9zOf9f2s6Q_Mk",
  authDomain: "artini-22c83.firebaseapp.com",
  databaseURL: "https://artini-22c83.firebaseio.com",
  projectId: "artini-22c83",
  storageBucket: "artini-22c83.appspot.com",
  messagingSenderId: "850015264518",
  appId: "1:850015264518:web:a0992497b42dec2f320887",
  measurementId: "G-XE11DK6PDX"
};
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();


//   <!-- The core Firebase JS SDK is always required and must be listed first -->
// <script src="https://www.gstatic.com/firebasejs/7.5.0/firebase-app.js"></script>

// <!-- TODO: Add SDKs for Firebase products that you want to use
//      https://firebase.google.com/docs/web/setup#available-libraries -->
// <script src="https://www.gstatic.com/firebasejs/7.5.0/firebase-analytics.js"></script>

// <script>
//   // Your web app's Firebase configuration
//   var firebaseConfig = {
//     apiKey: "AIzaSyCG9CEMR4ClQpP_X2dDkm9zOf9f2s6Q_Mk",
//     authDomain: "artini-22c83.firebaseapp.com",
//     databaseURL: "https://artini-22c83.firebaseio.com",
//     projectId: "artini-22c83",
//     storageBucket: "artini-22c83.appspot.com",
//     messagingSenderId: "850015264518",
//     appId: "1:850015264518:web:a0992497b42dec2f320887",
//     measurementId: "G-XE11DK6PDX"
//   };
//   // Initialize Firebase
//   firebase.initializeApp(firebaseConfig);
//   firebase.analytics();
// </script>